﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

/// <summary>
/// Summary description for Program
/// </summary>
public class Program
{


    public Program()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}