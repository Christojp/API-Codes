﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{


    protected void Page_Load(object sender, EventArgs e)
    {



         //APIGetMethod();
         APIGetMethodWeb();
       
        // APIPOSTMethod();
    }


    public void APIPOSTMethod()
    {
        // Refer to the documentation for more information on how to get the client id/secret
        string clientId = "rNoLtqc20N9DtY8YA9tQ5SCm7h55aG8GXvpUuxnI_6o=";
        string clientSecret = "rfRratdLjpN5mH0txYuPz8dmP6vJZ_bxbamoRp8QNZA=";
        // Refer to the documentation for more information on how to get the tokens
        string accessToken = "OaOXXXXTaSucp8XXcgXXH";
        string refreshToken = "kE4HXXXXXXXhxvtUHlboSF";

        // -- Refresh the access token
        System.Net.WebRequest request = System.Net.HttpWebRequest.Create("https://ob.natwest.useinfinite.io/token");
        request.Method = "POST";
        request.ContentType = "application/x-www-form-urlencoded";

        NameValueCollection outgoingQueryString = HttpUtility.ParseQueryString(String.Empty);
        outgoingQueryString.Add("grant_type", "client_credentials");
        outgoingQueryString.Add("client_id", clientId);
        outgoingQueryString.Add("client_secret", clientSecret);
        outgoingQueryString.Add("scope", "accounts");
        byte[] postBytes = new ASCIIEncoding().GetBytes(outgoingQueryString.ToString());

        Stream postStream = request.GetRequestStream();
        postStream.Write(postBytes, 0, postBytes.Length);
        postStream.Flush();
        postStream.Close();

        using (System.Net.WebResponse response = request.GetResponse())
        {
            using (System.IO.StreamReader streamReader = new System.IO.StreamReader(response.GetResponseStream()))
            {
                dynamic jsonResponseText = streamReader.ReadToEnd();
               
                // For more information, refer to the documentation
            }
        }
    }
    public void APIGetMethodWeb()
    {
        string clientId = "rNoLtqc20N9DtY8YA9tQ5SCm7h55aG8GXvpUuxnI_6o=";
        string clientSecret = "rfRratdLjpN5mH0txYuPz8dmP6vJZ_bxbamoRp8QNZA=";
        string accessToken = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHAiOiJWYWx1ZUNyZWF0b3JzQVBJIiwib3JnIjoidmFsdWVjcmVhdG9ycy5vcmciLCJpc3MiOiJuYXR3ZXN0LnVzZWluZmluaXRlLmlvIiwidG9rZW5fdHlwZSI6IkFDQ0VTU19UT0tFTiIsImV4dGVybmFsX2NsaWVudF9pZCI6InJOb0x0cWMyME45RHRZOFlBOXRRNVNDbTdoNTVhRzhHWHZwVXV4bklfNm89IiwiY2xpZW50X2lkIjoiN2UwM2Y0NmYtNjJmOC00MDI3LWJiMGYtNmY3NGU5YmEyZTAwIiwibWF4X2FnZSI6ODY0MDAsImF1ZCI6IjdlMDNmNDZmLTYyZjgtNDAyNy1iYjBmLTZmNzRlOWJhMmUwMCIsInVzZXJfaWQiOiIxMjM0NTY3ODkwMTJAdmFsdWVjcmVhdG9ycy5vcmciLCJncmFudF9pZCI6ImUzNmI5NjlkLTlmYmEtNDMyZC1iYjFhLTMxOWM2NDg1YWY0OSIsInNjb3BlIjoiYWNjb3VudHMgb3BlbmlkIiwiY29uc2VudF9yZWZlcmVuY2UiOiI3YWM2YzUyMC04M2I1LTQxM2MtYWI4Ny1iMzk0ZGUyOTJlNTUiLCJleHAiOjE1OTQ5MTc0MTAsImlhdCI6MTU5NDkxNzExMCwianRpIjoiY2FmMmM3ZmEtNGI2NS00YTYzLWI2YjUtOTgxMGJhNmQ1NDFhIiwidGVuYW50IjoiTmF0V2VzdCJ9.RwGYSxw8ndUanTnFAHILvbduCfeX0bDKq45hD3owrpgiCcnDasPysEeigXEWqjiWCuIV69FL00wUdlLV7E1Z2dEUcYh156TrJ8EP_V7JO8aIr7ZcpFkjDfAPVb9SMmIQVdl0dWVoPzprjvedWPuRp-sKxlX0JaMH2IqKH6fyWDReuRUJOPSjpL0vwoPQ8KGz1MmvqGwsuGYmHUtMnAzjzwfONBf4FBEk_2Q5_HPnd5y9DQV9fqdjtD48jpwZK44YQHKj1iJ8VAx0pbma6pftOqTfNyfxpcjZYK0mwLqIXvNB6uynocgHVmXNGqcEYsZNQwsd_sk5jvACee7JE1gjJw";
        string NWBID = "0015800000jfwxXAAQ";
        HttpWebResponse objHttpWebResponse = null;


        // string certName = @"C:\\Users\chris\Documents\Visual Studio 2015\WebSites\OpenAPI.p7b";


        //  ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
        System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        ServicePointManager.ServerCertificateValidationCallback += delegate { return true; };
        ServicePointManager.Expect100Continue = true;
        X509Certificate2Collection certificates = new X509Certificate2Collection();
     //   certificates.Import(certName, "", X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet);
      

        HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create("https://ob.natwest.useinfinite.io/open-banking/v3.1/aisp/accounts");
       // WebReq.ClientCertificates.Add(certName);
        //WebReq.UserAgent = "Client Cert Sample";
        //WebReq.Method = "GET";
       // WebReq.ClientCertificates = certificates;
        // ShowHttpWebRequest(WebReq);
        WebReq.Method = "GET";
        //WebReq.KeepAlive = false;
        WebReq.Headers.Add("Authorization", "Bearer " + accessToken);
        WebReq.Headers.Add("x-fapi-financial-id", NWBID);
        WebReq.PreAuthenticate = true;

         objHttpWebResponse = (HttpWebResponse)WebReq.GetResponse();
        if (objHttpWebResponse.StatusCode == HttpStatusCode.OK)
        {
            using (System.IO.StreamReader streamReader = new System.IO.StreamReader(objHttpWebResponse.GetResponseStream()))
            {
                dynamic jsonResponseText = streamReader.ReadToEnd();
            }
        }
    }

    private static bool ServerCertificateValidationCallback(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    {
        return (sslPolicyErrors == SslPolicyErrors.None);
       
    }


    public void APIGetMethod()
    {
       


    }


    public static void ShowHttpWebRequest(System.Net.HttpWebRequest hwr)
    {
        StringBuilder sb = new StringBuilder();
        if (null != hwr)
        {
            sb.Append("-----------------------------------------------HttpWebRequest" + System.Environment.NewLine);
            sb.Append(string.Format("HttpWebRequest.Address.AbsolutePath='{0}'", hwr.Address.AbsolutePath) + System.Environment.NewLine);
            sb.Append(string.Format("HttpWebRequest.Address.AbsoluteUri='{0}'", hwr.Address.AbsoluteUri) + System.Environment.NewLine);
            sb.Append(string.Format("HttpWebRequest.Address='{0}'", hwr.Address) + System.Environment.NewLine);

            sb.Append(string.Format("HttpWebRequest.RequestUri.AbsolutePath='{0}'", hwr.RequestUri.AbsolutePath) + System.Environment.NewLine);
            sb.Append(string.Format("HttpWebRequest.RequestUri.AbsoluteUri='{0}'", hwr.RequestUri.AbsoluteUri) + System.Environment.NewLine);
            sb.Append(string.Format("HttpWebRequest.RequestUri='{0}'", hwr.RequestUri) + System.Environment.NewLine);

            foreach (X509Certificate cert in hwr.ClientCertificates)
            {
                sb.Append("START*************************************************");
                ShowX509Certificate(sb, cert);
                sb.Append("END*************************************************");
            }
        }

        string result = sb.ToString();
        Console.WriteLine(result);
    }

    public static void ShowCertAndChain(X509Certificate2 cert)
    {
        X509Chain chain = new X509Chain();
        chain.ChainPolicy.RevocationFlag = X509RevocationFlag.EntireChain;
        chain.ChainPolicy.RevocationMode = X509RevocationMode.Offline;
        chain.ChainPolicy.VerificationFlags = X509VerificationFlags.AllFlags;

        ////chain.ChainPolicy.VerificationFlags = X509VerificationFlags.IgnoreCtlSignerRevocationUnknown &&
        ////X509VerificationFlags.IgnoreRootRevocationUnknown &&
        ////X509VerificationFlags.IgnoreEndRevocationUnknown &&
        ////X509VerificationFlags.IgnoreCertificateAuthorityRevocationUnknown &&
        ////X509VerificationFlags.IgnoreCtlNotTimeValid;

        chain.Build(cert);

        ShowCertAndChain(cert, chain);
    }

    public static void ShowCertAndChain(X509Certificate cert, X509Chain chain)
    {
        StringBuilder sb = new StringBuilder();
        if (null != cert)
        {
            ShowX509Certificate(sb, cert);
        }

        if (null != chain)
        {
            sb.Append("-X509Chain(Start)-" + System.Environment.NewLine);
            ////sb.Append(string.Format("Cert.ChainStatus='{0}'", string.Join(",", chain.ChainStatus.ToList())) + System.Environment.NewLine);

            foreach (X509ChainStatus cstat in chain.ChainStatus)
            {
                sb.Append(string.Format("X509ChainStatus::'{0}'-'{1}'", cstat.Status.ToString(), cstat.StatusInformation) + System.Environment.NewLine);
            }

            X509ChainElementCollection ces = chain.ChainElements;
            ShowX509ChainElementCollection(sb, ces);
            sb.Append("-X509Chain(End)-" + System.Environment.NewLine);
        }

        string result = sb.ToString();
        Console.WriteLine(result);
    }

    private static void ShowX509Extension(StringBuilder sb, int x509ExtensionCount, X509Extension ext)
    {
        sb.Append(string.Empty + System.Environment.NewLine);
        sb.Append(string.Format("--------X509ExtensionNumber(Start):{0}", x509ExtensionCount) + System.Environment.NewLine);
        sb.Append(string.Format("X509Extension.Critical='{0}'", ext.Critical) + System.Environment.NewLine);

        AsnEncodedData asndata = new AsnEncodedData(ext.Oid, ext.RawData);
        sb.Append(string.Format("Extension type: {0}", ext.Oid.FriendlyName) + System.Environment.NewLine);
        sb.Append(string.Format("Oid value: {0}", asndata.Oid.Value) + System.Environment.NewLine);
        sb.Append(string.Format("Raw data length: {0} {1}", asndata.RawData.Length, Environment.NewLine) + System.Environment.NewLine);
        sb.Append(asndata.Format(true) + System.Environment.NewLine);

        X509BasicConstraintsExtension basicEx = ext as X509BasicConstraintsExtension;
        if (null != basicEx)
        {
            sb.Append("-X509BasicConstraintsExtension-" + System.Environment.NewLine);
            sb.Append(string.Format("X509Extension.X509BasicConstraintsExtension.CertificateAuthority='{0}'", basicEx.CertificateAuthority) + System.Environment.NewLine);
        }

        X509EnhancedKeyUsageExtension keyEx = ext as X509EnhancedKeyUsageExtension;
        if (null != keyEx)
        {
            sb.Append("-X509EnhancedKeyUsageExtension-" + System.Environment.NewLine);
            sb.Append(string.Format("X509Extension.X509EnhancedKeyUsageExtension.EnhancedKeyUsages='{0}'", keyEx.EnhancedKeyUsages) + System.Environment.NewLine);
            foreach (Oid oi in keyEx.EnhancedKeyUsages)
            {
                sb.Append(string.Format("------------EnhancedKeyUsages.Oid.FriendlyName='{0}'", oi.FriendlyName) + System.Environment.NewLine);
                sb.Append(string.Format("------------EnhancedKeyUsages.Oid.Value='{0}'", oi.Value) + System.Environment.NewLine);
            }
        }

        X509KeyUsageExtension usageEx = ext as X509KeyUsageExtension;
        if (null != usageEx)
        {
            sb.Append("-X509KeyUsageExtension-" + System.Environment.NewLine);
            sb.Append(string.Format("X509Extension.X509KeyUsageExtension.KeyUsages='{0}'", usageEx.KeyUsages) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.CrlSign='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.CrlSign) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.DataEncipherment='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.DataEncipherment) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.DecipherOnly='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.DecipherOnly) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.DigitalSignature='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.DigitalSignature) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.EncipherOnly='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.EncipherOnly) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.KeyAgreement='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.KeyAgreement) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.KeyCertSign='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.KeyCertSign) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.KeyEncipherment='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.KeyEncipherment) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.None='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.None) != 0) + System.Environment.NewLine);
            sb.Append(string.Format("X509KeyUsageExtension.KeyUsages.X509KeyUsageFlags.NonRepudiation='{0}'", (usageEx.KeyUsages & X509KeyUsageFlags.NonRepudiation) != 0) + System.Environment.NewLine);
        }

        X509SubjectKeyIdentifierExtension skIdEx = ext as X509SubjectKeyIdentifierExtension;
        if (null != skIdEx)
        {
            sb.Append("-X509SubjectKeyIdentifierExtension-" + System.Environment.NewLine);
            sb.Append(string.Format("X509Extension.X509SubjectKeyIdentifierExtension.Oid='{0}'", skIdEx.Oid) + System.Environment.NewLine);
            sb.Append(string.Format("X509Extension.X509SubjectKeyIdentifierExtension.SubjectKeyIdentifier='{0}'", skIdEx.SubjectKeyIdentifier) + System.Environment.NewLine);
        }

        sb.Append(string.Format("--------X509ExtensionNumber(End):{0}", x509ExtensionCount) + System.Environment.NewLine);
    }

    private static void ShowX509Extensions(StringBuilder sb, string cert2SubjectName, X509ExtensionCollection extColl)
    {
        int x509ExtensionCount = 0;
        sb.Append(string.Format("--------ShowX509Extensions(Start):for:{0}", cert2SubjectName) + System.Environment.NewLine);
        foreach (X509Extension ext in extColl)
        {
            ShowX509Extension(sb, ++x509ExtensionCount, ext);
        }

        sb.Append(string.Format("--------ShowX509Extensions(End):for:{0}", cert2SubjectName) + System.Environment.NewLine);
    }

    private static void ShowX509Certificate2(StringBuilder sb, X509Certificate2 cert2)
    {
        if (null != cert2)
        {
            sb.Append(string.Format("X509Certificate2.SubjectName.Name='{0}'", cert2.SubjectName.Name) + System.Environment.NewLine);
            sb.Append(string.Format("X509Certificate2.Subject='{0}'", cert2.Subject) + System.Environment.NewLine);
            sb.Append(string.Format("X509Certificate2.Thumbprint='{0}'", cert2.Thumbprint) + System.Environment.NewLine);
            sb.Append(string.Format("X509Certificate2.HasPrivateKey='{0}'", cert2.HasPrivateKey) + System.Environment.NewLine);
            sb.Append(string.Format("X509Certificate2.Version='{0}'", cert2.Version) + System.Environment.NewLine);
            sb.Append(string.Format("X509Certificate2.NotBefore='{0}'", cert2.NotBefore) + System.Environment.NewLine);
            sb.Append(string.Format("X509Certificate2.NotAfter='{0}'", cert2.NotAfter) + System.Environment.NewLine);
            sb.Append(string.Format("X509Certificate2.PublicKey.Key.KeySize='{0}'", cert2.PublicKey.Key.KeySize) + System.Environment.NewLine);

            ////List<X509KeyUsageExtension> keyUsageExtensions = cert2.Extensions.OfType<X509KeyUsageExtension>().ToList();
            ////List<X509Extension> extensions = cert2.Extensions.OfType<X509Extension>().ToList();

            ShowX509Extensions(sb, cert2.Subject, cert2.Extensions);
        }
    }

    private static void ShowX509ChainElementCollection(StringBuilder sb, X509ChainElementCollection ces)
    {
        int x509ChainElementCount = 0;
        foreach (X509ChainElement ce in ces)
        {
            sb.Append(string.Empty + System.Environment.NewLine);
            sb.Append(string.Format("----X509ChainElementNumber:{0}", ++x509ChainElementCount) + System.Environment.NewLine);
            sb.Append(string.Format("X509ChainElement.Cert.SubjectName.Name='{0}'", ce.Certificate.SubjectName.Name) + System.Environment.NewLine);
            sb.Append(string.Format("X509ChainElement.Cert.Issuer='{0}'", ce.Certificate.Issuer) + System.Environment.NewLine);
            sb.Append(string.Format("X509ChainElement.Cert.Thumbprint='{0}'", ce.Certificate.Thumbprint) + System.Environment.NewLine);
            sb.Append(string.Format("X509ChainElement.Cert.HasPrivateKey='{0}'", ce.Certificate.HasPrivateKey) + System.Environment.NewLine);

            X509Certificate2 cert2 = ce.Certificate as X509Certificate2;
            ShowX509Certificate2(sb, cert2);

            ShowX509Extensions(sb, cert2.Subject, ce.Certificate.Extensions);
        }
    }

    private static void ShowX509Certificate(StringBuilder sb, X509Certificate cert)
    {
        sb.Append("-----------------------------------------------" + System.Environment.NewLine);
        sb.Append(string.Format("Cert.Subject='{0}'", cert.Subject) + System.Environment.NewLine);
        sb.Append(string.Format("Cert.Issuer='{0}'", cert.Issuer) + System.Environment.NewLine);

        sb.Append(string.Format("Cert.GetPublicKey().Length='{0}'", cert.GetPublicKey().Length) + System.Environment.NewLine);

        X509Certificate2 cert2 = cert as X509Certificate2;
        ShowX509Certificate2(sb, cert2);
    }
}